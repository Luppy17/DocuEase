# 403 Unauthorised Page in Tailwind CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/The-Anmol/pen/qBQQQLp](https://codepen.io/The-Anmol/pen/qBQQQLp).

